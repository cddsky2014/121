<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        我是首页<?php echo $title;?>

    </body>
</html>