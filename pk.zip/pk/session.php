<?php
session_start();//开启session

//$_SEESION=array();
$_SESSION['name']='rose';
$_SESSION['age']=18;
//echo session_save_path();//获取当前session保存的位置


//$_SESSION;$_COOKIE