<?php
//secookie("变量名","值","有效时间","cookie有效目录","cookie的作用域名")
$arr = array(
	'name'=>'lucy'
);
echo $arr['name'];//lucy
//$_COOKIE;
//$_COOKIE = array('name'=>'lucy');
setCookie('name','lucy',time()+10);

//unset($_COOKIE['name']);
//echo $_COOKIE['name'];
/*
名字：	name
内容：	lucy
域：	127.0.0.1
路径：	/pk
发送用途：	各种连接
脚本可访问：	是
创建时间：	2016年7月6日星期三 下午7:34:43
过期时间：	2016年7月6日星期三 下午7:34:53
*/
