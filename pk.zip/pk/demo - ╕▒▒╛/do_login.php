<?php

$uname = $_POST['uname'];
$pwd = $_POST['pwd'];
$time = $_POST['time']*24*3600;//将天数转化为秒数
setCookie('uname',$uname,time()+$time);//设置cookie
setCookie('pwd',$pwd,time()+$time);//设置cookie
echo '登陆成功';