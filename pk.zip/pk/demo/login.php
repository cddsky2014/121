<?php
/*
	if(isset($_COOKIE['uname'])){
		$uname = $_COOKIE['uname'];
	}else{
		$uname = '';
	}
*/
	//获取cookie用户名
	$uname = isset($_COOKIE['uname'])?$_COOKIE['uname']:'';
	//获取cookie密码
	$pwd = isset($_COOKIE['pwd'])?$_COOKIE['pwd']:'';
	
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="./do_login.php" method="post">
		用户名：<input type="text" name="uname" value=<?php echo $uname;?>><br>
		密码：<input type="password" name="pwd" value=<?php echo $pwd;?>><br>
		<select name="time">
			<option value="0">不保存</option>
			<option value="1">一天</option>
			<option value="7">一个星期</option>			
		</select>
		<br>
		<input type="submit" name="sub" value="登陆"><br>
		
	</form>

</body>
</html>