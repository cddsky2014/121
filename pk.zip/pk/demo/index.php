<?php
	session_start();
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

	<?php
		//如果登陆成功显示‘注销’和‘欢迎’
		if(isset($_SESSION['uname'])==true){
			$uname = $_SESSION['uname'];
			echo "欢迎你：$uname  <a href='./logout.php'>注销</a>";
		
		}else{		
			echo "<a href='./login.php'>登陆</a>  <a href=''>免费注册</a>";
		}
	?>
	

	
	<hr>

	
</body>
</html>