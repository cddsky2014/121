<?php
session_start();
//注销 删除session	
	session_destroy();
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	退出成功<a href="./index.php">返回</a>	
</body>
</html>