<?php
	session_start();
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php
	$uname = $_POST['uname'];
	$pwd = $_POST['pwd'];
	$time = $_POST['time']*24*3600;//将天数转化为秒数
	setCookie('uname',$uname,time()+$time);//设置cookie
	setCookie('pwd',$pwd,time()+$time);//设置cookie

	//admin,123
	if($uname=='admin' && $pwd=='123'){
		$_SESSION['uname']=$uname;//登陆成功保存用户名
		echo '登陆成功';
	}else{
		header('location:./login.php');
		exit;
	}
	
	?>
	<a href="./index.php">返回</a>
</body>
</html>
