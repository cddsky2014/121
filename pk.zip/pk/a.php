<?php
session_start();

//echo $arr['name'];
//echo $_COOKIE['name'];
echo $_SESSION['name'];
echo $_SESSION['age'];

/*
	session生存周期：浏览器开启到浏览器关闭
*/