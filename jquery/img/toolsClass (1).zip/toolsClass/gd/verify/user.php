<?php
	session_start();

	if($_SESSION['verify'] != md5($_POST['verifyCode'])){
		echo "No";
	}


?>