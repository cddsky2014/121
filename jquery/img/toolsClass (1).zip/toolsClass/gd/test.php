<?php
	require("String.class.php");
	require("Image.class.php");
	
	Image::thumb("s04.jpg","d1.jpg"); // 缩略图
?>