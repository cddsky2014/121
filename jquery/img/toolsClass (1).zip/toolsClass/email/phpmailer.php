<?php
	set_time_limit(0);  
	
	require("./phpmailer/PHPMailerAutoload.php");
	
	function sendMail($to,$subject,$content){
		$mail = new PHPMailer;
		//邮件服务器信息配置
        $mail -> ISSMTP();           //设置邮件发送协议 smtp|pop3|imap
        $mail -> CharSet = "utf-8";  //设置邮件编码
        $mail -> Port = 25;          //邮件端口
        $mail -> Host = "smtp.qq.com"; // 使用的邮件服务器
        $mail -> SMTPAuth = true;  //设置phpmail发送邮件是否需要校验(username&password)

        if($mail -> SMTPAuth){
            $mail -> Username = "360042659@qq.com";
            $mail -> Password = "liujian..00";  
        }
		$mail -> From = "360042659@qq.com";    //来源from
        $mail -> IsHTML(true);                 //是否发送html邮件
       
        //发送邮件信息
		$mail -> Addaddress($to);               // to
		$mail -> Subject = $subject;            // subject
		$mail -> Body = $content;               // content
		$mail -> AddAttachment('PHPMailer-master.zip','a.zip'); // 添加附件,并指定名称 
		
		if($mail->send()){
			return true;
		}else{
			return false;
		}
	}
	$arr = array(
		'792199622',
		'1243988715',
		'422960144',
	);
	
	foreach($arr as $vo){
		sendMail($vo."@qq.com","妞","<h1>呵呵!</h1>");
	}
	



?>