<?php
	require("./Http.class.php");
	$http = new Http();
	$http->download("","a.rpm");

?>

<a href="?fid=webmin-1.590-1.noarch.rpm">�����ļ�</a>