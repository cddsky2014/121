<meta charset="utf-8"/>
<?php
/*
maxSize 文件上传的最大文件大小（以字节为单位），0为不限大小 
savePath 文件上传的保存路径（相对于根路径） 
saveName 上传文件的保存规则，支持数组和字符串方式定义 
replace 存在同名文件是否是覆盖，默认为false 
exts 允许上传的文件后缀（留空为不限制），使用数组或者逗号分隔的字符串设置，默认为空 
mimes 允许上传的文件类型（留空为不限制），使用数组或者逗号分隔的字符串设置，默认为空 
*/
  require("UploadFile.class.php");
	if($_POST['doSubmit']){
		$upload = new UploadFile();// 实例化上传类
		$upload->maxSize  = 3145728 ;// 设置附件上传大小
		$upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		$upload->savePath =  './Uploads/';// 设置附件上传目录
		
		if($upload->upload()) {
			// 上传成功 获取上传文件信息
			$info =  $upload->getUploadFileInfo();
			print_r($info);
		}else{
			// 上传错误提示错误信息
			echo $upload->getErrorMsg();
		}
	}
  
?>
<form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="upFile[]"/>
		<input type="file" name="upFile[]"/>
		<input type="file" name="upFile[]"/>
		<input type="submit" value="上传" name="doSubmit">
</form>