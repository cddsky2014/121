<?php 
require './excel.php';
header('Content-type:text/html;charset=utf-8;');

$file = $_FILES['excel'];

if($file['error'] != 0){
	$errorMessage .= '上传错误代码：'.$file['error']."</br>";
}

//文件类型检查
if ("xls" == substr($file['name'],strrpos($file['name'], '.')+1)) {
	$new_name = "./".time().".xls";
	$copy_status = move_uploaded_file($file['tmp_name'], $new_name);
	
	//文件上传没有问题，开始读取导入数据
	$data = new Spreadsheet_Excel_Reader($new_name);
	
	// 获取第一行excel列说明信息
	$header = array();
	$header[] = $data->sheets[0]['cells'][1][1];
	$header[] = $data->sheets[0]['cells'][1][2];
	$header[] = $data->sheets[0]['cells'][1][2];
	
	$content = array();
	for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {	
		$nickName = $data->sheets[0]['cells'][$i][1];
		$schoolName = $data->sheets[0]['cells'][$i][2];
		$mark = $data->sheets[0]['cells'][$i][3];
		
		$content[$i-2]['nickName'] = $nickName;
		$content[$i-2]['schoolName'] = $schoolName;
		$content[$i-2]["mark"] = $mark;	
	}
	$sql = "insert into a (nickName,schoolName,mark) values";
	foreach($content as $vo){
		$sql .= "('".$vo['nickName']."','".$vo['schoolName']."','".$vo['mark']."'),";
	}
	$sql = substr($sql,0,-1);
	echo $sql;
	
	@unlink($new_name);
}else{
	echo $errorMessage = "导入的文件类型不正确！";
}



?>