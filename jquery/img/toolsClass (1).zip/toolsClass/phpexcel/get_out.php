<?php 

if (empty($start_time) || ($start_time != date('Y-m-d',strtotime($start_time)))) 
{
	$start_time = "1970-01-01";
}

if (empty($end_time) || ($end_time != date('Y-m-d',strtotime($end_time))))
{
	$end_time = date('Y-m-d');
}

$filename = '人人通使用情况统计('.$start_time.'-'.$end_time.').xls';

ob_end_clean();

Header( "Content-type:application/octet-stream");
Header( "Accept-Ranges:bytes");
Header( "Content-type:application/vnd.ms-excel");
Header( "Content-Disposition:attachment;filename=$filename");

echo "单位名称\t日志 \t图片\t状态 \t分享 \t投票\t评论";

// 从数据库读取数据
// $data 二维数组
$data = array(
	array(1,2,3,4,5,6,7),
	array(1,2,3,4,5,6,7),
	array(1,2,3,4,5,6,7),
	array(1,2,3,4,5,6,7),
);

foreach ($data as $orgname => $val){						
	echo "\n";
	echo "".$val[0];
	echo "\t".$val[1];
	echo "\t".$val[2];
	echo "\t".$val[3];
	echo "\t".$val[4];
	echo "\t".$val[5];
	echo "\t".$val[6];
}
exit();

 ?>